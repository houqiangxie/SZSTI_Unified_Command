<template>
  <div class="text-[18px]">我是我大大实打实</div>
  <div text="[40px] " bg="[#f00]" >dsdsds</div>
  {{a}}
</template>


<script lang="ts" setup>
import {ref} from 'vue'
  const a  = ref<number>(333)
</script>