module.exports = {
  extends: [
    'vue-global-api', 
  ]
};